function color1() {
    document.querySelector("#square1").style.backgroundColor = "purple";
}

function color2() {
    document.querySelector("#square2").style.backgroundColor = "yellow";
}

function color3() {
    document.querySelector("#square3").style.backgroundColor = "red";
}

function color4() {
    document.querySelector("#square4").style.backgroundColor = "blue";
}

function color5() {
    document.querySelector("#square5").style.backgroundColor = "pink";
}

function color6() {
    document.querySelector("#square6").style.backgroundColor = "orange";
}